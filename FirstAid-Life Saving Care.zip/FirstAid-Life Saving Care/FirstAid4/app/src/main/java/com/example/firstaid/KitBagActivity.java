package com.example.firstaid;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

import Home_App.CustomList;
import Home_App.Listview_adapter;

public class KitBagActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kit_bag);
        ListView listView = findViewById(R.id.listview2);
        ArrayList<CustomList> arrayList = new ArrayList<>();
        arrayList.add(new CustomList(R.drawable.bandage_icon,"Bandages"));
        arrayList.add(new CustomList(R.drawable.bloodpressure_icon,"Blood Pressure Monitor"));
        arrayList.add(new CustomList(R.drawable.wounds_icon,"Cleaning Wounds"));
        arrayList.add(new CustomList(R.drawable.tape_icon,"Dressing Tape"));
        arrayList.add(new CustomList(R.drawable.thermometer_icon,"Thermometer"));

        Listview_adapter listview_adapter = new Listview_adapter(this, R.layout.customlistview, arrayList);
        listView.setAdapter(listview_adapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0){
                    Intent intent = new Intent(view.getContext(),BandagesActivity.class);
                    startActivity(intent);
                }
                if(i==1){
                    Intent intent = new Intent(view.getContext(),BloodPressureActivity.class);
                    startActivity(intent);
                }
                if(i==2){
                    Intent intent = new Intent(view.getContext(),WoundActivity.class);
                    startActivity(intent);
                }
                if(i==3){
                    Intent intent = new Intent(view.getContext(),TapeActivity.class);
                    startActivity(intent);
                }
                if(i==4){
                    Intent intent = new Intent(view.getContext(),ThermometerActivity.class);
                    startActivity(intent);
                }
            }
        });




    }
}
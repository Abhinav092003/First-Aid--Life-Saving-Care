package com.example.firstaid.ui.instructions;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.firstaid.DealEmergencyActivity;
import com.example.firstaid.KitBagActivity;
import com.example.firstaid.LawsActivity;
import com.example.firstaid.R;
import com.example.firstaid.RecoveryActivity;
import com.example.firstaid.databinding.FragmentGalleryBinding;

public class GalleryFragment extends Fragment {

    private FragmentGalleryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        GalleryViewModel galleryViewModel =
                new ViewModelProvider(this).get(GalleryViewModel.class);

        binding = FragmentGalleryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();


        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ImageView laws = view.findViewById(R.id.laws);
        ImageView dealemergency = view.findViewById(R.id.dealemergency);
        ImageView recovery = view.findViewById(R.id.recovery);
        ImageView kitbag = view.findViewById(R.id.kitbag);



        laws.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), LawsActivity.class);
                startActivity(intent);
            }
        });

        recovery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), RecoveryActivity.class);
                startActivity(intent);
            }
        });

        dealemergency.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), DealEmergencyActivity.class);
                startActivity(intent);
            }
        });

        kitbag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), KitBagActivity.class);
                startActivity(intent);
            }
        });




    }
}